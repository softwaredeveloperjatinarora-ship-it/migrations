import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";
import CustomizerReducer from "./customizer/CustomizerSlice";
import MenuReducer from './menu/menuSlice'
import AsyncStorage from '@react-native-async-storage/async-storage';
import ProfileReducer from './profile/profileSlice'

const persistConfig = {
  key: "root",
  // storage,
  storage: AsyncStorage
};

export const store = configureStore({
  reducer: {
    customizer: persistReducer<any>(persistConfig, CustomizerReducer),
    menu: MenuReducer,
    profile:ProfileReducer
     
  },
  devTools: process.env.NODE_ENV !== "production",
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ serializableCheck: false, immutableCheck: false }),
});

const rootReducer = combineReducers({
  customizer: CustomizerReducer,
});

const menuReducer = combineReducers({
  menu: MenuReducer
});
const profileReducer = combineReducers({
  profile:ProfileReducer
});



export const persistor = persistStore(store);
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export type AppState = ReturnType<typeof rootReducer>;
export type menuState = ReturnType<typeof menuReducer>;
export type ProfileState = ReturnType<typeof profileReducer>;

