"use client";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';

import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Image from "next/image";
import Link from "next/link";
import { usePathname } from 'next/navigation';
import React, { useEffect } from "react";

export default function NotFound() {
  const pathname = usePathname();
  const [loading, setLoading] = React.useState(true);
  //This Component is Handle Both cases Not - Found and Auto Login
  useEffect(() => {
        let loginName = pathname.split("/").filter(Boolean).at(-1); // gets last segment
        if(!loginName) return ;
        if(loginName?.length <= 500) {
          setLoading(false);
        }
  }, []);
  return (
    <Box>
      {
        loading ?(
          <Box>...........</Box>
        ):(
          <Box
      display="flex"
      flexDirection="column"
      height="100vh"
      textAlign="center"
      justifyContent="center"
    >
      <Container maxWidth="md">
        <Image
          src={"/images/backgrounds/errorimg.svg"}
          alt="404"
          width={500}
          height={500}
          style={{ width: "100%", maxWidth: "500px", maxHeight: "500px" }}
        />
        <Typography align="center" variant="h1" mb={4}>
          Opps!!!
        </Typography>
        <Typography align="center" variant="h4" mb={4}>
          This page you are looking for could not be found.
        </Typography>
        <Button
          color="primary"
          variant="contained"
          component={Link}
          href="/dashboard"
          disableElevation
        >
          Go Back to Home
        </Button>
      </Container>
    </Box>
        )
      }
    </Box>
  );
}
