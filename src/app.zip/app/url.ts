const isProd = process.env.NODE_ENV === "production";

const apiurl = isProd
  ? process.env.NEXT_PUBLIC_API_URL_PROD
  : process.env.NEXT_PUBLIC_API_URL_DEV;

const urls = {
  baseurl: apiurl,
};

export default urls;
