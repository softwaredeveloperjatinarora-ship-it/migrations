'use client'
import Breadcrumb from '@/app/dashboard/(DashboardLayout)/layout/shared/breadcrumb/Breadcrumb';
import React from 'react'
import CertificateTabs from './CertificateTabs';

const StudentCertificate = () => {


    const BCrumb = [
        {
          to: "/dashboard",
          title: "Home",
        },
        {
          title: "Certificate Request",
        },
      ];
  return (
    <>
    <Breadcrumb title="Certificate Request" items={BCrumb} />
     <CertificateTabs/>
    </>
  )
}

export default StudentCertificate
