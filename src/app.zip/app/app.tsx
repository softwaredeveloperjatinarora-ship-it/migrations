// "use client";
// import React from "react";
// import { ThemeProvider } from "@mui/material/styles";
// import CssBaseline from "@mui/material/CssBaseline";
// import RTL from "@/app/dashboard/(DashboardLayout)/layout/shared/customizer/RTL";
// import { ThemeSettings } from "@/utils/theme/Theme";
// import { useSelector } from 'react-redux';
// import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter';
// import { AppState } from "@/store/store";
// import { SessionProvider } from "next-auth/react"
// import "@/utils/i18n";
// import "@/app/api/index";
// import NextTopLoader from 'nextjs-toploader';



// const MyApp = ({ children,session }: { children: React.ReactNode,session:any }) => {
//     const theme = ThemeSettings();
//     const customizer = useSelector((state: AppState) => state.customizer);

//     return (
//         <>

//         <SessionProvider session={session}>
//         <NextTopLoader />
//             <AppRouterCacheProvider options={{ enableCssLayer: true }}>
//                 <ThemeProvider theme={theme}>
//                     <RTL direction={customizer.activeDir}>
//                         <CssBaseline />
//                         {children}
//                     </RTL>
//                 </ThemeProvider>
//             </AppRouterCacheProvider>
//         </SessionProvider>
//         </>
//     );
// };

// export default MyApp;


'use client';
import React from 'react';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import RTL from '@/app/dashboard/(DashboardLayout)/layout/shared/customizer/RTL';
import { ThemeSettings } from '@/utils/theme/Theme';
import { useSelector } from 'react-redux';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter';
import type { AppState } from '@/store/store';
import { SessionProvider } from 'next-auth/react';
import { Session } from 'next-auth';
import '@/utils/i18n';
import NextTopLoader from 'nextjs-toploader';
import { useActivityTracker } from '@/utils/useActivityTracker';
import { disableConsoleInProduction } from '@/utils/consoleblocker';
import AutoLoginss from '@/utils/logins';


interface MyAppProps {
  children: React.ReactNode;
  session?: Session;
}

disableConsoleInProduction();
const MyApp = ({ children, session }: MyAppProps) => {
  const theme = ThemeSettings();
  const customizer = useSelector((state: AppState) => state.customizer);

  return (
    
    <SessionProvider
      session={session}
      refetchOnWindowFocus={true}
    >
      
      <NextTopLoader
        color="#5D87FF"
        height={3}
        showSpinner={false}
      />
      <AppRouterCacheProvider options={{ enableCssLayer: true }}>
        <ThemeProvider theme={theme}> 
          <RTL direction={customizer.activeDir}>
            <CssBaseline enableColorScheme />
            <ActivityTrackerWrapper>
               <AutoLoginss />
              {children}
            </ActivityTrackerWrapper>
          </RTL>
        </ThemeProvider>
      </AppRouterCacheProvider>
    </SessionProvider>
  );
};

// Wrapper component for proper provider nesting
const ActivityTrackerWrapper = ({ children }: { children: React.ReactNode }) => {
  useActivityTracker();
  return <>{children}</>;
};

export default MyApp;