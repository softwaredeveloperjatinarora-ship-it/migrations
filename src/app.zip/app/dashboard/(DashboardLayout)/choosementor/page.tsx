'use server'
import PageContainer from "@/app/components/container/PageContainer"
import StudentMentorPreferencePage from "@/app/components/views/choosementorViews/MentorMain"

const Choosementor = () => {
  return (
    <PageContainer title="Mentor Choose" description="Mentor Choose" >
     <StudentMentorPreferencePage  />
    </PageContainer>
  )
}
export default Choosementor
