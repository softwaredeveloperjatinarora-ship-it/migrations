'use server'
import PageContainer from "@/app/components/container/PageContainer"
import OJTMaindashboard from "@/app/components/views/OJTDashboardView/OJTMaindashboard"


const OJTDashboard= () => {
  return (
    <PageContainer title="ojt" description="ojt" >
     <OJTMaindashboard />
    </PageContainer>
  )
}
export default OJTDashboard
