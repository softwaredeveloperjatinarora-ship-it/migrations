'use server'

import PageContainer from "@/app/components/container/PageContainer";

import ProfileBanner from "@/app/components/views/ProfilePageViews/ProfileBanner";


const UserProfile = () => {
  return (
    <PageContainer title="Profile" description="this is Profile">
    
          <ProfileBanner />
      
    </PageContainer>
  );
};

export default UserProfile;
