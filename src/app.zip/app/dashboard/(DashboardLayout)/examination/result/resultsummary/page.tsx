

'use client';

import React from 'react';
import PageContainer from '@/app/components/container/PageContainer';
import ResultTabs from '@/app/components/views/ExaminationViews/ResultView/ResultTabs';
 // Assuming it's in the same folder

const Page = () => {
  return (
    <PageContainer title="Result Summary" description="Result Summary">
<ResultTabs bred={true} />
    </PageContainer>
  );
};

export default Page;

