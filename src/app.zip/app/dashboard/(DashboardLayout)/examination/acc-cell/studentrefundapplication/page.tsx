import PageContainer from "@/app/components/container/PageContainer"
import StudentRefundApplication from "@/app/components/views/ExaminationViews/AccCell/StudentRefundApplication";

const StudentRefund = () => {
  return (
    <PageContainer title="Refund Application" description="Refund Application">
     <StudentRefundApplication/>
    </PageContainer>
  )
}

export default StudentRefund