
import PageContainer from "@/app/components/container/PageContainer"
import StuDegreeExtension from "@/app/components/views/ExaminationViews/AccCell/StuDegreeExtensionView";

const page = () => {
  return (
    <PageContainer title="Degree Extension" description="Degree Extension">
     <StuDegreeExtension/>
    </PageContainer>
  )
}

export default page