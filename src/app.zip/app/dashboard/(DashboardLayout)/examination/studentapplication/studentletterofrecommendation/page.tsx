'use server'
import PageContainer from "@/app/components/container/PageContainer"
import StudentLetterOfRecommendation from "@/app/components/views/ExaminationViews/StudentApplication/StudentLetterOfRecommendation";

const page = () => {
  return (
    <PageContainer title="Degree Extension" description="Degree Extension">
     {<StudentLetterOfRecommendation/>}
    </PageContainer>
  )
}

export default page