import SelfLeanringMaterial from "@/app/components/views/ExaminationViews/AcdemicSuppport/SelfLearningMaterial/SelfLeanringMaterial"
import React from "react"

const selfLearning = () => {
        return (
            <SelfLeanringMaterial />
        )
}
 export default selfLearning;