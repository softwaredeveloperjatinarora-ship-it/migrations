'use server'
import PageContainer from "@/app/components/container/PageContainer"
import SeatingPlanView from "@/app/components/views/ExaminationViews/Conduct/SeatingPlanView"


const page = () => {
  return (
    <PageContainer title="Seating Plan" description="Seating Plan">
     {<SeatingPlanView/>}
    </PageContainer>
  )
}

export default page
