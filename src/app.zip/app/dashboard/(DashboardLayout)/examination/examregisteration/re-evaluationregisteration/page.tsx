import PageContainer from '@/app/components/container/PageContainer'
import StuReEvaluationRegisteration from '@/app/components/views/ExaminationViews/ExamRegistration/StuReEvaluationRegisteration'
import React from 'react'

const page = () => {
  return (
    <PageContainer title="ReEvaluation Registeration" description="ReEvaluation Registeration">
     <StuReEvaluationRegisteration/>
    </PageContainer>
  )
}

export default page
