import PageContainer from '@/app/components/container/PageContainer'
import StuReAppearRegistertion from '@/app/components/views/ExaminationViews/ExamRegistration/StuReAppearRegistertion'
import React from 'react'

const page = () => {
  return (
     <PageContainer title="ReAppear Registeration" description="ReAppear Registeration">
     <StuReAppearRegistertion/>
      </PageContainer>
  )
}

export default page
