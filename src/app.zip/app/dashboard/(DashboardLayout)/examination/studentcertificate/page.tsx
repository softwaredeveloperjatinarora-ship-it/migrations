'use server'
import PageContainer from "@/app/components/container/PageContainer"
import StudentCertificate from "@/app/components/views/ExaminationViews/StudentCertificate/StudentCertificate";

const page = () => {
  return (
    <PageContainer title="Student Certificate" description="Student Certificate">
     {<StudentCertificate/>}
    </PageContainer>
  )
}

export default page