import ScholarCreditCardScheme from '@/app/components/views/ExaminationViews/CredititCardScheme/ScholarCredititCardScheme'
import React from 'react'


const CreditCardScheme = () => {
    
  return (
    <div>
      <ScholarCreditCardScheme />
    </div>
  )
}

export default CreditCardScheme
