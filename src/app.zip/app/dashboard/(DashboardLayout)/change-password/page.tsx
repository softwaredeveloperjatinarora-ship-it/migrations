'use server'
import PageContainer from "@/app/components/container/PageContainer";
import ChangePassword from "@/app/components/views/ChangepasswordViews/AuthChangePassword";

const Changepassword = () => {
  return (
    <PageContainer title="Change Password" description="Change Password">
     <ChangePassword />
    </PageContainer>
  )
}
export default Changepassword
