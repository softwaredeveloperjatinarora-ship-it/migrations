'use server'
import PageContainer from "@/app/components/container/PageContainer"
import DigitalLibrary from "@/app/components/views/DigitallibraryViews/Digitallibrary"
const DigitalLib = () => {
  return (
    <PageContainer title="Digital Library" description="Seating Plan" >
      <DigitalLibrary />
    </PageContainer>
  )
}
export default DigitalLib
