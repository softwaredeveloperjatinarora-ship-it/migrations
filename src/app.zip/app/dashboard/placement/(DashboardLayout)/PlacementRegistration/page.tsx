import PageContainer from "@/app/components/container/PageContainer";
 
import AutoLoginss from "@/utils/logins";
 

  export default async function PlacementRegistration() {
     
     
  return (
    <PageContainer  title="Placement Registration"   description="this is Placement Page" >      
        
        <h1>placement pages</h1>
     </PageContainer>
  );
};