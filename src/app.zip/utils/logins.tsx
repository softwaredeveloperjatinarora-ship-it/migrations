// "use client";
// import { signIn } from "next-auth/react";
// import { usePathname, useRouter } from "next/navigation";
// import { useEffect } from "react";
// import { useSession } from 'next-auth/react';

// export default function AutoLoginss() {
//   const pathname = usePathname();
//   const router = useRouter();
 

//   useEffect(() => {
//     const loginName = pathname.split("/").filter(Boolean).at(-1); // gets last segment
//     const storedLoginName = localStorage.getItem("loginName");

//     if (!loginName || status === "authenticated") return;

//     const autoLogin = async () => {
//       if (storedLoginName && storedLoginName !== loginName) {
//         localStorage.removeItem("token");
//       }

//       localStorage.setItem("loginName", loginName);

//       const result = await signIn("credentials", {
//         redirect: false,
//         urlParam: pathname,
//       });

//       // if (!result || result.error) {
//       //   router.push("/dashboard");
//       // }
//     };
//   console.log("loginanem",loginName)
//       autoLogin();
//     }, [pathname, router, status]);

//   return null; // important: since this isn't a UI component
// }




//Pushpender


"use client"
import axios from "axios";
import { signIn, useSession } from "next-auth/react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef } from "react";


export default function AutoLoginss() {
  const pathname = usePathname();
  const router = useRouter();
  const hasRun = useRef(false);  
  const { data: session, status } = useSession();
  const pathSegments = pathname.split("/").filter(Boolean);
  const cleanRedirectPath = "/" + pathSegments.slice(0, -1).join("/"); // Final path
  const segments = pathname.split("/").filter(Boolean);
  const lastSegment = segments.at(-1);
  const isToken = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(lastSegment || "");
  useEffect(() => {
    debugger;
    console.log('Session is',session);
    if(session && isToken)
    {
      router.push(cleanRedirectPath);
      return;
    }
  
    const loginName = pathname.split("/").filter(Boolean).at(-1); // gets last segment
    // const storedLoginName = localStorage.getItem("loginName");
    const restUrl=pathname.split("/").slice(0,-1).join('/') || ('//');
    // console.log(restUrl);
    if (!loginName || status === "authenticated") return;

    const autoLogin = async () => {
          try {
          //    console.log(loginName);
              debugger;
                if(!session)
    {
            const res = await axios.post('https://localhost:7125/security/createcommonumstoken', {
              userName: loginName,
              menuName: "test"
            }, {
              headers: {
                'Content-Type': 'application/json'
              }
            });
                const result = await signIn("credentials", {
                      redirect: false,
                      urlParam: res.data,
                    });
                    // console.log("result",result);
                    if (!result || result.error) {

                      router.push('/studentdashboard');
                    }else{
                      router.push(restUrl);
                    }
                  }
          } catch (error) {
            console.error('Error:', error);
          }
    };     
          autoLogin();
        
    }, [pathname]);

  return null;  
}
