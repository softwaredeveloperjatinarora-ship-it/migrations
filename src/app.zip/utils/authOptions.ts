

import NextAuth, { NextAuthOptions, User, getServerSession } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { SignJWT } from "jose"; // Correct import for 'jose'
import { createSecretKey } from "crypto"; // Node.js built-in module for creating secret keys

import {
  GetServerSidePropsContext,
  NextApiRequest,
  NextApiResponse,
} from "next";
import urls from "@/app/url";



interface CustomUser extends User {
  username: string;
  email: string;
  token: string; // Add the token or other properties if needed
}

const encryptionKey = process.env.JWT_SECRET || "your-secret-key-here"; // 09-12-2024

const authOptions: NextAuthOptions = {
 providers: [
   CredentialsProvider({
    name: "Credentials",
    credentials: {
      urlParam: { label: "URL Path", type: "text" },
    },
    async authorize(credentials) {
      const url = credentials?.urlParam;
      //  console.log('url is',JSON.stringify(credentials));
      if (!url) return null;
    
      // Extract loginName from second last segment of path
      const segments = url.split("/"); // e.g., /common/ums123/dashboard
      const loginName = segments[segments.length - 1];
      
      if (!loginName) return null;
      else
      {
      try {
          const user: CustomUser = {
              id: loginName, // Adjust based on the API response
              username: "User Logged in",
              email:loginName, // Adjust if necessary
              token: loginName, // Include the token if necessary
            };
          //  console.log('user is',JSON.stringify(user));
            return user;
      } catch (error) {
        return null;
      }
    }
    },
  }),
],


  callbacks: {

    // async redirect({ url }) {
    //   const baseUrl = process.env.NEXTAUTH_URL || "http://172.19.2.214:4001"; // Fallback for local
    //   return url.startsWith(baseUrl) ? url : `${baseUrl}/dashboard`; // Redirect to /dashboard
    // },
    //  async redirect({ url, baseUrl }) {
    //         try {
    //           const targetUrl = url.startsWith("http") ? new URL(url) : new URL(url, baseUrl);
    //           const segments = targetUrl.pathname.split("/");
    //           const lastSegment = segments[segments.length - 1];

    //           const jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/;
    //           if (jwtRegex.test(lastSegment)) {
    //             segments.pop(); // Remove JWT
    //             const cleanPath = segments.join("/");
    //             return new URL(cleanPath, baseUrl).toString();
    //           }

    //           if (targetUrl.origin === new URL(baseUrl).origin) {
    //             return targetUrl.toString();
    //           }

    //           return `${baseUrl}/dashboard`;
    //         } catch (err) {
    //           console.error("Redirect error:", err);
    //           return `${baseUrl}/dashboard`;
    //         }
    //         },

    async signIn({ user, account, profile, email, credentials }) {
      if (user) {
        return true;
      }

      return false;
    },

    async jwt({ token, user, trigger }) {
      if (user) {
        console.log(' user in jwt is',JSON.stringify(user));
        token._id = user.id?.toString();
        token.isVerified = user.isVerified;
        token.isAcceptingMessage = user.isAcceptingMessage;
        token.username = user.username;
        token.email = user.email;
        token.token = user.token;

           // Ensure tokenExpires and lastActivity are set as numbers
           token.tokenExpires = Number(Date.now() + 15 * 60 * 1000);  // 15 minutes expiration  
           token.lastActivity = Number(Date.now());
           
      }

      // Token refresh logic
      if (trigger === "update") {
        
        // console.log("Trigeerravi",token.token)
        token.lastActivity = Number(Date.now());
        
      }

      // Handle token expiration and refresh if necessary
      if (user || token?.token) {
      if (typeof token.tokenExpires === 'number' && token.tokenExpires - Date.now() < 1 * 60 * 1000) {
        try {
          // console.log("refresh token call")
          if (!token.token) throw new Error("No token available for refresh");
         
          const refreshResponse = await fetch(`${urls.baseurl}/security/refreshtoken`, 
            
            {
            method: "POST",
            
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${token.token}`,
            },
            body: JSON.stringify({}),
            
          },);

          if (!refreshResponse.ok) throw new Error("Refresh failed");

          const refreshData = await refreshResponse.json();
          // console.log("Newtoke",refreshData.token)," ";
          if (refreshData?.status === true) {
            token.token = refreshData.token;
            token.tokenExpires = Number(Date.now() + 15 * 60 * 1000);  // 15 minutes expiration
            token.lastActivity = Number(Date.now());
          }
        } catch (error) {
          // console.error("Token refresh failed:", error);
        }
      }
    }

      return token;
    },

    async session({ session, token }) {
      // Assert that token.token and token.id are strings
      if (token) {
        session.user._id = token._id; // Type assertion
        session.user.isVerified = token.isVerified;

        session.user.token = token.token;
        session.user.name = "User Logged in";
      }

      return session;
    },
  },
  // Configure cookies
  cookies: {
    sessionToken: {
      name: "next-auth.session-token",
      options: {
        httpOnly: true,
        secure: false,
        sameSite: "lax",
        path: "/"
      },
    },
  },
  session: {
    strategy: "jwt", // Make sure this is set to 'jwt'
    maxAge: 15 * 60, // Max session duration: 15 minutes (in seconds)
  },
  secret: process.env.NEXTAUTH_SECRET, // Make sure the secret is configured
};

function auth( // <-- use this function to access the jwt from React components
  ...args:
    | [GetServerSidePropsContext["req"], GetServerSidePropsContext["res"]]
    | [NextApiRequest, NextApiResponse]
    | []
) {
  return getServerSession(...args, authOptions);
}

export { authOptions, auth };